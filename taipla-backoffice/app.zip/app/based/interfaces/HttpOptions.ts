export interface XHttpOptions {
    parameters?: any,
    headers?: any,
    method?: string
}
