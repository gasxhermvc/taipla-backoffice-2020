import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-center',
  templateUrl: './food-center.component.html',
  styleUrls: ['./food-center.component.scss']
})
export class FoodCenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
