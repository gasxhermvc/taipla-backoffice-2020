import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-um',
  templateUrl: './um.component.html',
  styleUrls: ['./um.component.scss']
})
export class UmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
